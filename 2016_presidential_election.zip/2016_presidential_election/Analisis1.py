import csv

#Read csv files
#Read primary results
f = open('primary_results.csv')

reader = csv.reader(f)

results = []
count_results = 0
for row in reader:
	if count_results != 0:
		results.append([row[0], row[1], row[2], row[3], 
			row[4], row[5], eval(row[6]), eval(row[7])])
	count_results += 1

count_results -= 1

f.close()

#Read county facts
f = open('county_facts.csv')

reader = csv.reader(f)

cfacts = []
count_cfacts = 0
for row in reader:
	if count_cfacts != 0:
		cfacts.append(row)
	count_cfacts += 1

count_cfacts -= 1

f.close()

#Read county facts dictionary
f = open('county_facts_dictionary.csv')

reader = csv.reader(f)

cfacts_dict = []
count_cfacts_dict = 0
for row in reader:
	if count_cfacts_dict != 0:
		cfacts_dict.append(row)
	count_cfacts_dict += 1

count_cfacts_dict -= 1

f.close()

#Functions
#Function to check if fips exist in list
def checkFips(fips, flist):
	found = False
	for row in flist:
		if fips in row:
			found = True
			break
	return found

#Function to return index where first x is found
#precond : x is in the list
def getIndex(x, l):
	idx = 0
	for row in l:
		if x in l:
			return idx
		else:
			idx += 1

#Get list of county with the highest votes
listHiVotesCounty = []
idx = -1
for row in results:
	if checkFips(row[3], listHiVotesCounty):
		if listHiVotesCounty[idx][1] < row[6]:
			listHiVotesCounty[idx][1] = row[6]
	else:
		idx += 1
		listHiVotesCounty.append([row[3],row[6]])

#Get list of county where Trump get the highest votes
listTrumpCounty = []
for row1 in listHiVotesCounty:
	for row2 in results:
		if row1[0] in row2 and row1[1] in row2:
			if row2[5] == 'Donald Trump':
				listTrumpCounty.append(row1)
			break

#Get list of county facts from listTrumpCounty
listCFactsTrump = []
for row1 in listTrumpCounty:
	for row2 in cfacts:
		if row1[0] == row2[0]:
			listCFactsTrump.append(row2)
			break

#Get avg percentage of county fact of bachelor's degree or higher
listBach = [eval(row[23]) for row in cfacts]
print('Average percentage of bachelor\'s degree =', sum(listBach)/len(listBach))

#Get avg percentage of county fact of bachelor's degree or higher
#in county where Trump wins votes
listBachTrump = [eval(row[23]) for row in listCFactsTrump]
print('Average percentage of Trump\'s voters with bachelor\'s degree =', sum(listBachTrump)/len(listBachTrump))