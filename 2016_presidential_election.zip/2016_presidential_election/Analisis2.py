import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import style
style.use('ggplot')

#Read .csv to data frame
df_results = pd.read_csv('primary_results.csv')
df_facts = pd.read_csv('county_facts.csv')
df_dicts = pd.read_csv('county_facts_dictionary.csv')

#Get primary results with only the highest votes / county
df_hicountyvotes = df_results.groupby('fips')['votes'].max().reset_index()
hicountyvotes_list = df_hicountyvotes.values.tolist()
results_list = df_results.values.tolist()
hiresults_list = []
for row in results_list:
	if [row[3], row[6]] in hicountyvotes_list:
		hiresults_list.append(row)

df_hiresults = pd.DataFrame(hiresults_list, columns=list(df_results))

#Setting up plots
fig, axes = plt.subplots(nrows=3, ncols=1, sharex=False)

#Count the election winnings grouped by candidate and plot
df_winnings = df_hiresults.groupby('candidate')['votes'].count()
df_winnings.plot(kind = 'bar', ax=axes[0], title='Number of Counties the Candidate Winning')

#Join results with highest votes with its facts based on fips
df_hifacts = pd.merge(df_hiresults, df_facts, on='fips')

#Get the mean of voters with bachelor's degree per candidate and plot
df_avgbach = df_hifacts.groupby('candidate')['EDU685213'].mean()
df_avgbach.plot(kind = 'bar', ax=axes[1], title='Mean of Bachelor\'s Degree')

#Get mean of selected factors per candidate
df_factors = df_hifacts.groupby('candidate')['SEX255214','RHI125214','RHI225214','RHI325214','RHI425214',
	'RHI525214','RHI625214','RHI725214','RHI825214','EDU635213','EDU685213',
	'VET605213','LFE305213','HSG010214','HSG445213','HSG096213','HSG495213',
	'HSD410213','HSD310213','INC910213','INC110213','PVY020213','BZA010213',
	'BZA110213','NES010213','SBO001207','SBO315207','SBO115207','SBO215207',
	'SBO515207','SBO415207','SBO015207','MAN450207','WTN220207','RTN130207',
	'RTN131207','AFN120207','BPS030214'].mean()

#Test out each factors per candidate
print('Mean of female voters percentage per candidate:')
print(df_hifacts.groupby('candidate')['SEX255214'].mean())

print('\nMean of voters percentage per candidate grouped by race:')
print(df_hifacts.groupby('candidate')['RHI125214','RHI225214','RHI325214','RHI425214',
	'RHI525214','RHI625214','RHI725214','RHI825214'].mean())

print('\nMean of voters high school graduate or higher percentage per candidate:')
print(df_hifacts.groupby('candidate')['EDU635213'].mean())

print('\nMean of veteran voters per candidate:')
print(df_hifacts.groupby('candidate')['VET605213'].mean())

print('\nMean of mean travel time voters go to work per candidate:')
print(df_hifacts.groupby('candidate')['LFE305213'].mean())

print('\nMean of voters housing criteria per candidate:')
print(df_hifacts.groupby('candidate')['HSG010214','HSG445213','HSG096213','HSG495213',
	'HSD410213','HSD310213'].mean())

print('\nMean of voters income criteria per candidate:')
print(df_hifacts.groupby('candidate')['INC910213','INC110213'].mean())

print('\nMean of voters below poverty level percentage per candidate:')
print(df_hifacts.groupby('candidate')['PVY020213'].mean())

print('\nMean of voters owning and working for private nonfarm per candidate:')
print(df_hifacts.groupby('candidate')['BZA010213','BZA110213'].mean())

print('\nMean of voters owning and working for private nonfarm per candidate:')
print(df_hifacts.groupby('candidate')['NES010213'].mean())

print('\nMean of voters firms and firms percentage by race per candidate:')
print(df_hifacts.groupby('candidate')['SBO001207','SBO315207','SBO115207','SBO215207',
	'SBO515207','SBO415207','SBO015207'].mean())

print('\nMean of voters with manifacturers shipments per candidate:')
print(df_hifacts.groupby('candidate')['MAN450207'].mean())

print('\nMean of voters merchant, retail, food, and accomodation sales per candidate:')
print(df_hifacts.groupby('candidate')['WTN220207','RTN130207','RTN131207','AFN120207']
	.mean())

print('\nMean of voters with building permits per candidate:')
print(df_hifacts.groupby('candidate')['BPS030214'].mean())

#Get the factors where Trump either get minimum or maximum mean
print('\nFactors candidate for Trump winning the election are:')
print('RHI425214, LFE305213, HSG096213')

#Get the deviation of factors mean per candidate
df_hifactors = df_hifacts.groupby('candidate')['RHI425214','LFE305213','HSG096213'].mean().std()

#Get 2 strongest factors
print('\nFactors candidate deviation by mean per candidate:')
print(df_hifactors)

#Plot all factors mean per candidate
df_hifactors.plot(ax=axes[2], title='Factors Standard Deviation')

print('\n3 factors for Trump winning the elction are:')
print('1. From people who don\'t live in multi-unit structures.')
print('2. From people who take a long time to travel to work.')
print('3. From people who don\'t have bachelor\'s degree.')

#Export factors mean per candidate to .csv
df_factors.to_csv('count_facts_per_candidate.csv')

#Show plot
plt.show()